#include<stdio.h>
#include<string.h>
#include <stdbool.h>
#include "inventory.h" 

void printOperations(){
     printf("\nInventory Management System\n");
     printf("1. Add Item\n");
     printf("2. Display All Items\n");
     printf("3. Search Item by ID\n");
     printf("4. Update Item Details by ID\n");
     printf("5. Delete Item by ID\n");
     printf("6. Calculate Total Inventory Value\n");
     printf("7. Exit\n");
}

void printItem(Inventory *inventory,int index){
    printf("%-5d %-20s %-10d %-10.2f\n",
               inventory->item[index].id,
               inventory->item[index].name,
               inventory->item[index].quantity,
               inventory->item[index].price);
}

// Function to display all items
void displayItems(Inventory *inventory) {
    if (inventory->count == 0) {
        printf("No items in inventory.\n");
        return;
    }

    printf("\n%-5s %-20s %-10s %-10s\n", "ID", "Name", "Quantity", "Price");
    printf("-----------------------------------------------------\n");
    for (int i = 0; i < inventory->count; i++) {
        printItem(inventory,i);
    }
}

int main(){

   int choice,id,quantity,index;
   float price;
   char name[MAX_NAME_LENGTH];

   Inventory inventory;
   initInventory(&inventory);

   do{
        printOperations();
        printf("Enter your choice\n");
        scanf("%d",&choice);

        switch (choice){
        case 1:
            printf("Enter item ID: ");
            scanf("%d",&id);
            getchar(); // Clear the buffer
            printf("Enter item name: ");
            scanf("%[^\n]s",name);
            printf("Enter quantity: ");
            scanf("%d",&quantity);
            printf("Enter price: ");
            scanf("%f",&price);

            bool isAdded = addItem(&inventory,id,name,quantity,price);
            isAdded ? printf("Item added successfully!\n") : printf("Inventory is full! Cannot add more items.\n");
            break;
        case 2:
            displayItems(&inventory);
            break;
        case 3:
            int searchId;
            printf("Enter item ID to search: ");
            scanf("%d", &searchId);
            index = searchItem(&inventory,searchId);
            index != -1 ? printItem(&inventory,index): printf("Item not found in inventory\n");
            break;
        case 4:
            int updateId;
            printf("Enter item ID to update: \n");
            scanf("%d", &updateId);
            getchar();
            index = searchItem(&inventory,updateId);
            if(index == -1){
                printf("Item not found in inventory\n");
                break;
            }
            printf("Enter New item name: ");
            scanf("%[^\n]s",name);
            getchar();
            printf("Enter New quantity: ");
            scanf("%d",&quantity);
            printf("Enter New price: ");
            scanf("%f",&price);

            updateItem(&inventory,index,name,quantity,price);
            printf("Item Updated Successfully!!!\n");
            break;        
        case 5:
            int deleteId;
            printf("Enter item ID to update: \n");
            scanf("%d", &deleteId);
            getchar();
            index = searchItem(&inventory,deleteId);
            if(index == -1){
                printf("Item not found in inventory\n");
                break;
            }

            deleteItem(&inventory,index);
            printf("Item Deleted Successfully!!!\n");
            break;
        case 6:
            float totalValue = calculateTotalValue(&inventory);
            printf("Total inventory value: %.2f\n", totalValue);
            break;    
        case 7:
            //freeInventory(&inventory);
            printf("Exiting the program. Goodbye!\n");
            break;        
        default:
            printf("Please enter the valid choice");
            break;
        }
   }while(choice!=7);

   return 0;
}