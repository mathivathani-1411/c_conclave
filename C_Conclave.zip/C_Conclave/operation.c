#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "inventory.h"

#define  INITIAL_CAPACITY 10


// Function to initialize the inventory
void initInventory(Inventory *inventory){
    inventory->capacity =  INITIAL_CAPACITY;
    inventory->count = 0;
    inventory->item = (Item *)malloc(inventory->capacity * sizeof(Item));
}


// Function to add an item
bool addItem(Inventory *inventory,int id,char name[],int quantity,float price){

    if(inventory->count >= inventory->capacity){
        return false;
        //resizeInventory(inventory);
    }
    Item newItem;
    newItem.id = id;
    strcpy(newItem.name,name);
    newItem.quantity = quantity;
    newItem.price = price;

    inventory->item[inventory->count] = newItem;
    inventory->count++;

    return true;
}

// Function to search for an item by ID
int searchItem(const Inventory *inventory,int searchId){
    for(int i=0;i<inventory->count;i++){
        if(inventory->item[i].id == searchId){
            return i;
        }
    }
    return -1;
}

// Function to update an item's details
void updateItem(Inventory *inventory,int index,char name[],int quantity,float price){
    strcpy(inventory->item[index].name,name);
    inventory->item[index].quantity = quantity;
    inventory->item[index].price = price;
}

// Function to delete an item by ID
void deleteItem(Inventory *inventory,int index){
    for(int i=index;i<inventory->count-1;i++){
        inventory->item[i] = inventory->item[i+1];
    }
    inventory->count--;
}

// Function to calculate total inventory value
float calculateTotalValue(const Inventory *inventory){
    float totalValue = 0.0;
    for(int i=0;i<inventory->count;i++){
        totalValue += inventory->item[i].quantity * inventory->item[i].price;
    }
    return totalValue;
}


// Function to resize the inventory dynamically
void resizeInventory(Inventory *inventory) {
    inventory->capacity *=2;
    Item *newItems = (Item *)realloc(inventory->item, inventory->capacity * sizeof(Item));
    inventory->item = newItems;
}

// Function to free allocated memory
void freeInventory(Inventory *inventory) {
    free(inventory->item);
}